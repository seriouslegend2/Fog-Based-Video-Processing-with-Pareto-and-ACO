import cv2
import requests
import time

# Set the fog node’s IP address and endpoint
FOG_NODE_URL = "http://fog-service:5001/process"

def capture_and_send():
    cap = cv2.VideoCapture(0)
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        _, img_encoded = cv2.imencode('.jpg', frame)
        response = requests.post(FOG_NODE_URL, data=img_encoded.tobytes(), headers={'Content-Type': 'application/octet-stream'})
        print("Sent frame to fog node, received response:", response.text)
        time.sleep(1)  # Control the frame rate
    cap.release()

if __name__ == "__main__":
    capture_and_send()
