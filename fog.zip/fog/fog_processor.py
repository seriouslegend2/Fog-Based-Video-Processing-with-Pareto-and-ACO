import cv2
import numpy as np
from flask import Flask, request
import requests

CLOUD_NODE_URL = "http://cloud-service:5002/store"

app = Flask(__name__)

@app.route('/process', methods=['POST'])
def process_frame():
    img_data = np.frombuffer(request.data, np.uint8)
    frame = cv2.imdecode(img_data, cv2.IMREAD_COLOR)

    # Red ball detection
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    lower_red = np.array([0, 100, 100])
    upper_red = np.array([10, 255, 255])
    mask = cv2.inRange(hsv, lower_red, upper_red)
    if np.any(mask):
        print("Red ball detected")
        requests.post(CLOUD_NODE_URL, json={"detection": "Red ball detected"})
    else:
        print("No red ball detected")

    return "Processed"

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001)
